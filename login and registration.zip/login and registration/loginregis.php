<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="loginregis.css">
    <script src="../jquery.js"></script>
    <script src="../node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <title>Document</title>
    <style>
        .error {
            color: red;
        }
        .errors{
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
<?php
// Establish database connection
include '../config.php';
$fullName = $email = $reg_password = $confirmPassword = "";
$fullNameError = $emailError = $passwordError = $confirmPasswordError = "";
$error_msg = "";
session_start();
// Check connection
if (isset($_POST['signup'])) {
    $fullName = $_POST['fullName'];
    $email = $_POST['reg_email'];
    $password = $_POST['reg_password'];
    
    // Check if email exists
    $checkEmailQuery = "SELECT * FROM users WHERE email = '$email' LIMIT 1";
    $result = mysqli_query($conn, $checkEmailQuery);
    
    if (mysqli_num_rows($result) > 0) {
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Email already exists!'
            });
            </script>";
        $emailError = "Email already exists. Please try again.";
    } else {
        // Validate fullname
        $fullnamePattern = "/^[a-zA-Z\s.,]+$/"; // Allow only letters, spaces, dots, and commas
        if (!preg_match($fullnamePattern, $fullName)) {
            // Fullname is invalid
            echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid Full Name',
                    text: 'Full name can only contain letters, spaces, dots, and commas.'
                });
                </script>";
        } else {
            // Validate email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                // Email is invalid
                echo "<script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Invalid Email',
                        text: 'Please enter a valid email address.'
                    });
                    </script>";
            } else {
                // All validations passed, redirect to OTP page
                $_SESSION['fullName'] = $fullName;
                $_SESSION['reg_email'] = $email;
                $_SESSION['reg_password'] = $password;
                header("location: otp");
                exit(); // Make sure to exit after header redirection
            }
        }
    }
}
?>
    <div class="wrapper">
        <div class="errors">
            <p><?php echo $error_msg; ?></p>
        </div>
        <div class="title-text">
            <div class="title login"><span class="Agri">Agri</span>Learn</div>
            <div class="title signup">Join <span class="Agri">Us </span>Now!</div>
        </div>
        <div class="form-container">
            <div class="slide-controls">
            <input type="radio" name="slide" id="login">
            <input type="radio" name="slide" id="signup">
                <label for="login" class="slide login">Login</label>
                <label for="signup" class="slide signup">Signup</label>
                <div class="slider-tab"></div>
            </div>
            <div class="form-inner">
                <!-- Login Form -->
                <form action="" method="post" class="login" id="Form">
                    <div class="field">
                        <input type="text" placeholder="Email Address" name="email" id="loginemail" required>
                        
                    </div>
                    <div class="field">
                        <input type="password" placeholder="Password" name="password" id="loginpass" required>
                        
                    </div>
                    <div class="pass-link"><a href="#">Forgot password?</a></div>
                    <div class="field btn">
                        <div class="btn-layer"></div>
                        <input type="submit" value="Login" name="login">
                    </div>
                    <div class="signup-link">Not a member? <a href="">Signup now</a></div>
                </form>
                <!-- Signup Form -->
                <form id ="RegForm" method="post">
                    <div class="field">
                        <input type="text" placeholder="Full Name" name="fullName" id="fullname" required value="<?php echo $fullName; ?>">
                        <p class="error" id="fullNameError"><?php echo $fullNameError; ?></p>
                    </div>
                    <div class="field">
                        <input type="email" placeholder="Email Address" name="reg_email" id="regemail" required value="<?php echo $email; ?>" >
                        <p class="error" id="emailError"><?php echo $emailError; ?></p>
                    </div>
                    <div class="field">
                        <input type="password" placeholder="Password" name="reg_password" id="regpass" required value="<?php echo $reg_password; ?>" >
                        <p class="error" id="passwordError"><?php echo $passwordError; ?></p>
                    </div>
                    <div class="field">
                        <input type="password" placeholder="Confirm password" name="confirmPassword" id="confirmPassword" required>
                        <p class="error" id="confirmPasswordError"><?php echo $confirmPasswordError; ?></p>
                    </div>
                    <div class="field btn">
                        <div class="btn-layer"></div>
                        <input type="submit" value="Signup" name="signup" id="signupButton">
                    </div>
                </form>

            </div>
        </div>
    </div>
<script>
$(document).ready(function() {
        $('#Form').submit(function(event) {
        event.preventDefault(); // Prevent form from submitting the traditional way

        // Collect form data
        var data = {
            email: $('#loginemail').val(),
            password: $('#loginpass').val()
        };

        // Send AJAX request
       // AJAX request to loginprocess.php
    $.ajax({
        url: 'loginprocess',
        type: 'POST',
        data: data,
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Login successful
                Swal.fire({
                    icon: 'success',
                    title: 'Login Successful',
                    text: 'Redirecting...',
                    showConfirmButton: false,
                    timer: 1500
                }).then(() => {
                    // Redirect to the specified URL
                    window.location.href = response.redirect;
                });
            } else {
                // Login failed
                if (response.message.includes('Invalid password.')) {
                    // Specific SweetAlert for invalid password with attempts remaining
                    Swal.fire({
                        icon: 'error',
                        title: 'Invalid Password',
                        html: response.message,
                        showConfirmButton: true,
                        allowOutsideClick: false, // Prevent closing when clicking outside
                        timer: 30000 // Auto close after 10 seconds
                    });
                } else {
                    let timerInterval;
                    Swal.fire({
                    title: "Login Failed",
                    icon: 'error',
                    html: "Please try again after <b></b> seconds.",
                    timer: 30000, // 30000 milliseconds = 30 seconds
                    timerProgressBar: true,
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                        const timer = Swal.getPopup().querySelector("b");
                        timerInterval = setInterval(() => {
                        timer.textContent = `${Math.ceil(Swal.getTimerLeft() / 1000)}`;
                        }, 100);
                    },
                    willClose: () => {
                        clearInterval(timerInterval);
                    }
                    }).then((result) => {
                    /* Read more about handling dismissals below */
                    if (result.dismiss === Swal.DismissReason.timer) {
                        console.log("I was closed by the timer");
                    }
                    });

                }
            }
        },
        error: function(xhr, status, error) {
            // Handle any errors
            Swal.fire({
                icon: 'error',
                title: 'An error occurred',
                text: 'Please try again later.',
                showConfirmButton: true // Enable OK button
            });
            console.error('AJAX request failed:', error);
        }
    });

        });
    });
// Function to trigger input event
    function triggerInputEvent(element) {
        const event = new Event('input', {
            bubbles: true,
            cancelable: true,
        });
        element.dispatchEvent(event);
    }

    // Function to check if there are any errors
    function checkErrors() {
        const fullNameError = document.getElementById('fullNameError').textContent;
        const emailError = document.getElementById('emailError').textContent;
        const passwordError = document.getElementById('passwordError').textContent;
        const confirmPasswordError = document.getElementById('confirmPasswordError').textContent;
        return (
            fullNameError !== '' ||
            emailError !== '' ||
            passwordError !== '' ||
            confirmPasswordError !== ''
        );
    }
    // Function to validate email format
    function validateEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    // Function to validate name format
    function validateName(name) {
        const regex = /^[a-zA-Z'-.\s]*$/;
        return regex.test(name);
    }

    // Function to validate password length
    function validatePassword(password) {
        return password.length >= 8  && password.length <=20;
    }

    // Function to validate password format
    function validatePasswordFormat(password) {
        const regex = /^[^'"]*$/;
        return regex.test(password);
    }

    // Function to disable or enable the submit button based on error presence
    function toggleSubmitButton() {
        const submitButton = document.getElementById('signupButton');
        submitButton.disabled = checkErrors();
    }

    // Add event listeners to input fields to monitor changes and perform validations
    const inputFields = document.querySelectorAll('input');
    inputFields.forEach(function(inputField) {
        inputField.addEventListener('input', function() {
            const fullName = document.getElementById('fullname').value;
            const email = document.getElementById('regemail').value;
            const password = document.getElementById('regpass').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            // Perform name validation if there is input
            const fullNameError = document.getElementById('fullNameError');
            if (fullName.trim() !== '') {
                if (!validateName(fullName)) {
                    fullNameError.textContent = 'Invalid full name format.';
                } else {
                    fullNameError.textContent = '';
                }
            }

            // Perform email validation if there is input
            const emailError = document.getElementById('emailError');
            if (email.trim() !== '') {
                if (!validateEmail(email)) {
                    emailError.textContent = 'Invalid email format.';
                } else {
                    emailError.textContent = '';
                }
            }

            // Perform password validation if there is input
            const passwordError = document.getElementById('passwordError');
            if (password.trim() !== '') {
                if (!validatePassword(password)) {
                    passwordError.textContent = 'Password must be atleast 8 - 20 characters.';
                } else if (!validatePasswordFormat(password)) {
                    passwordError.textContent = 'Password contains invalid characters.';
                }else {
                    passwordError.textContent = '';
                }
            }

            // Perform password matching validation if there is input
            const confirmPasswordError = document.getElementById('confirmPasswordError');
            if (confirmPassword.trim() !== '') {
                if (password !== confirmPassword) {
                    confirmPasswordError.textContent = 'Passwords do not match.';
                } else {
                    confirmPasswordError.textContent = '';
                }
            }

            toggleSubmitButton();
        });

        // Trigger input event on each input field to monitor changes
        triggerInputEvent(inputField);
    });


      // Initially disable the submit button
      toggleSubmitButton();

      // Function to switch between login and signup forms
      const loginText = document.querySelector(".title-text .login");
      const loginForm = document.querySelector("form.login");
      const loginBtn = document.querySelector("label.login");
      const signupBtn = document.querySelector("label.signup");
      const signupLink = document.querySelector("form .signup-link a");
      signupBtn.onclick = (()=>{
        loginForm.style.marginLeft = "-50%";
        loginText.style.marginLeft = "-50%";
      });
      loginBtn.onclick = (()=>{
        loginForm.style.marginLeft = "0%";
        loginText.style.marginLeft = "0%";
      });
      signupLink.onclick = (()=>{
        signupBtn.click();
        return false;
      });
      document.addEventListener('contextmenu', function (e) {
        e.preventDefault();
      });
    // Disable keyboard shortcuts
    document.onkeydown = function (e) {
        if (e.ctrlKey && 
            (e.keyCode === 67 || // 'C'
             e.keyCode === 86 || // 'V'
             e.keyCode === 85 || // 'U'
             e.keyCode === 83 || // 'S'
             e.keyCode === 73 || // 'I'
             e.keyCode === 123   // F12
            )) {
            return false;
        }
    };
</script>

</body>
</html>
