<?php
// Include your database connection file and start the session
require_once '../config.php';
session_start();

// Retrieve and sanitize form data from the POST request
$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
$password = $_POST['password'];

// Initialize an array to hold the response
$response = [];

// Check if there's a login attempt session variable
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}

// Check if the user has exceeded the maximum login attempts
if ($_SESSION['login_attempts'] >= 3 && isset($_SESSION['last_login_attempt'])) {
    $time_diff = time() - $_SESSION['last_login_attempt'];
    if ($time_diff < 30) {
        // User is temporarily locked out
        $response['success'] = false;
        $response['message'] = 'Too many login attempts. Please wait for ' . (30 - $time_diff) . ' seconds.';
        
        // Return the response as JSON
        header('Content-Type: application/json');
        echo json_encode($response);
        exit(); // Terminate further execution
    }
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    // Invalid email format
    $response['success'] = false;
    $response['message'] = 'Invalid email address format.';
    
    // Return the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Query the database for the user with the provided email
$checkUsernameQuery = "SELECT * FROM users WHERE email = ? LIMIT 1";
$stmt = $conn->prepare($checkUsernameQuery);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User found in the database
    $row = $result->fetch_assoc();
    $hashed_password = $row['password'];

    // Verify the password
    if (password_verify($password, $hashed_password)) {
        // Reset login attempts on successful login
        $_SESSION['login_attempts'] = 0;

        // Set the session email
        $_SESSION['email'] = $email;

        // Check user status and redirect accordingly
        if ($row['status'] == 1) {
            // If user is an instructor
            $response['success'] = true;
            $response['redirect'] = '../instructor/instructor';
        } else {
            // If user is not an instructor, redirect to another page (or handle accordingly)
            $response['success'] = true;
            $response['redirect'] = 'nyeow';
        }
    } else {
        // Invalid password
        $_SESSION['login_attempts']++; // Increment login attempts
        $_SESSION['last_login_attempt'] = time(); // Record the time of the last login attempt
        $remaining_attempts = 3 - $_SESSION['login_attempts'];
        
        if ($remaining_attempts > 0) {
            $response['success'] = false;
            $response['message'] = 'Invalid password. ' . $remaining_attempts . ' attempts remaining.';
        } else {
            $time_diff = time() - $_SESSION['last_login_attempt'];
            $response['success'] = false;
            $response['message'] = 'Too many login attempts. Please wait for ' . (30 - $time_diff) . ' seconds.';
            $_SESSION['last_login_attempt'] = time(); // Record the time of the last login attempt
        }
    }
} else {
    // No user found with the provided email
    $_SESSION['login_attempts']++; // Increment login attempts
    $_SESSION['last_login_attempt'] = time(); // Record the time of the last login attempt
    $remaining_attempts = 3 - $_SESSION['login_attempts'];

    if ($remaining_attempts > 0) {
        $response['success'] = false;
        $response['message'] = 'Invalid email address. ' . $remaining_attempts . ' attempts remaining.';
    } else {
        $time_diff = time() - $_SESSION['last_login_attempt'];
        $response['success'] = false;
        $response['message'] = 'Too many login attempts. Please wait for ' . (30 - $time_diff) . ' seconds.';
        $_SESSION['last_login_attempt'] = time(); // Record the time of the last login attempt
    }
}

// Close the prepared statement
$stmt->close();

// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
