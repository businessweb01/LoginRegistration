<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="../node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
</head>
<body>
    <?php 
    session_start();
    if(isset($_SESSION['email'])) {
        include "../config.php";
        
        $sql = mysqli_query($conn, "SELECT * FROM `users` WHERE `email` = '$_SESSION[email]'");
        $row = mysqli_fetch_assoc($sql);
        $name = $row['fullname'];
        echo "<h1>Hello $name</h1>";
    } else {    
        
        header("Location: loginregis");
    }
    ?>
    <a href="../logout.php"><input type="button" value="Logout"></a>
</body>
<script>
    Swal.fire({
        title: "helloe ser gel,pasa niyo na kami pls ",
        width: 600,
        padding: "3em",
        color: "#716add",
        background: "#fff url(/images/trees.png)",
        backdrop: `
            rgba(0,0,123,0.4)
            url("../images/batman.gif")
            center top
            repeat
            
        `
    });
</script>
</html>
