<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <script src="../node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: verdana;
        }

        body {
            height: 100vh;
            width: 100%;
            background-image: linear-gradient(to bottom right, #C8C1AC, #FFE794);
            background-size: cover;
            background-position: center;
        }

        /* Container styles */
        .container {
            height: 80vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 1rem;
            margin-left: 1rem;
        }

        /* Form styles */
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 300px;
            border: 1px solid #ccc;
        }

        /* Input styles */
        input[type="email"],
        input[type="number"] {
            margin: 5px;
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
            border-radius: 10px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            margin: 5px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100px;
        }

        input[type="submit"]:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        h2 {
            margin: 10px 0;
            width: 100%;
            text-align: center;
        }

        /* Countdown timer styles */
        #countdown {
            margin-top: 10px;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
include('../config.php');

// Start the session to store OTP and last OTP sent time
session_start();

$fullname = $_SESSION['fullName'];
$email = $_SESSION['reg_email'];
$regpass = $_SESSION['reg_password'];

// Function to generate OTP
function generateOTP($length = 6) {
    $characters = '0123456789';
    $otp = '';
    for ($i = 0; $i < $length; $i++) {
        $otp .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $otp;
}

// Function to check if it's been less than a minute since the last OTP sent
function isLessThanMinute() {
    if (isset($_SESSION['last_otp_sent_time']) && time() - $_SESSION['last_otp_sent_time'] < 60) {
        return true;
    }
    return false;
}

if (isset($_POST['send_otp'])) {
    if (isLessThanMinute()) {
        // Less than a minute has passed since the last OTP sent
        echo '<script>
        let timerInterval;
        Swal.fire({
        icon: "warning",
        html: "Please try again after <b></b> seconds.",
        timer: 60000,
        timerProgressBar: true,
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
            const timer = Swal.getPopup().querySelector("b");
            timerInterval = setInterval(() => {
            timer.textContent = Math.ceil(Swal.getTimerLeft() / 1000);
            }, 100);
        },
        willClose: () => {
            clearInterval(timerInterval);
        }
        }).then((result) => {
        if (result.dismiss === Swal.DismissReason.timer) {
            console.log("I was closed by the timer");
        }
        });
    </script>';
    } else {
        // Fetch email address
        $to_email = $_SESSION['reg_email'];

        // Generate OTP
        $otp = generateOTP();

        // Store OTP and last OTP sent time in session
        $_SESSION['otp'] = $otp;
        $_SESSION['reg_email'] = $to_email; 
        $_SESSION['last_otp_sent_time'] = time(); // Store current time

        try {
            // PHPMailer configuration
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'eugenevanlinsangan1204@gmail.com'; // Update with your Gmail address
            // Go to Google to your Google account and generate an app password
            $mail->Password = 'fsxq muut uklx kila'; // Update with your Gmail password
            $mail->SMTPSecure = 'tls'; 
            $mail->Port = 587;

            // Email content
            $mail->setFrom('eugenevanlinsangan1204@gmail.com', 'OTP Verification'); // Update with your Gmail address
            $mail->addAddress($to_email);
            $mail->Subject = 'Your One-Time Password (OTP)';
            $mail->Body = 'Your OTP is: ' . $otp;

            // Send email
            $mail->send();
            echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'OTP Sent Successfully',
                    text: 'An OTP has been sent to $to_email. Please enter the OTP to complete the registration process.'
                });
            </script>";
        } catch (Exception $e) {
            $message_otp = "Failed to send OTP. Please try again. Error: {$mail->ErrorInfo}";
        }
    }
} elseif (isset($_POST['verify_otp'])) {
    // Fetch OTP entered by the user
    $user_otp = $_POST['otp'];

    // Verify OTP
    if (isset($_SESSION['otp']) && $_SESSION['otp'] == $user_otp) {
        // OTP verified correctly
        // Hash the password using PASSWORD_DEFAULT
        $hashpassword = password_hash($regpass, PASSWORD_DEFAULT);
    
        // Insert the user's data into the users table
        $stmt = $conn->prepare("INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $fullname, $email, $hashpassword);
        $result = $stmt->execute();
        if ($result) {
            // Registration successful
            echo "<script>Swal.fire({
                icon: 'success',
                title: 'Registration Successful',
                text: 'You have been successfully registered. You can now login.'
            }).then(() => {
                window.location.href = 'loginregis';
            });</script>";
            // Clear the session after successful registration
            session_destroy();
        } else {
            // Registration failed
            echo "<script>Swal.fire({
                icon: 'error',
                title: 'Registration Failed',
                text: 'An error occurred while processing your registration. Please try again later.'
            });</script>";
        }
        // Close the prepared statement
        $stmt->close();
    } else {
        // If the OTP does not match, display an error message
        echo "<script>Swal.fire({
            icon: 'error',
            title: 'Invalid OTP',
            text: 'The entered OTP is invalid. Please try again.'
        });</script>";
    }
}
?>
    <div class="container">
        <form action="" method="post">
            <h2>OTP Verification</h2>
            <input type="submit" value="Send OTP" name="send_otp" id="send_otp_button">
            <h2>Verify OTP</h2>
            <input type="number" name="otp" maxlength="6" placeholder="Enter 6-digit OTP">
            <input type="submit" value="Verify OTP" name="verify_otp" id="verify_otp_button">
            <div id="countdown"></div>
        </form>
    </div>
    
</body>
</html>
